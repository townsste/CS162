#include "Game.hpp"

int main()
{
	Game gObj;


	gObj.gameSettings();

	//cin.get();
	//cin.get();

	return 0;
}